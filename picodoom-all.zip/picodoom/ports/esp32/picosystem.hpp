// PicoSystem-API shim for ESP32 / ESP32-S3 boards with a TFT_eSPI display and 6 push buttons.
// Set your pins in platformio.ini (build_flags) or edit the defaults below.
#pragma once
#include <Arduino.h>
#include <TFT_eSPI.h>
#include <stdint.h>
#ifndef PIN_UP
#define PIN_UP 32
#define PIN_DOWN 33
#define PIN_LEFT 25
#define PIN_RIGHT 26
#define PIN_A 27
#define PIN_B 14
#define PIN_X 12
#define PIN_Y 13
#endif
#ifndef PD_SCALE
#define PD_SCALE 2            // 120x120 game -> 240x240 on screen
#endif
extern TFT_eSPI pd_tft; extern uint32_t pd_held, pd_prev; extern uint16_t pd_col;
namespace picosystem {
  static const uint32_t UP=1,DOWN=2,LEFT=4,RIGHT=8,A=16,B=32,X=64,Y=128;
  inline void pen(int r,int g,int b,int a=15){(void)a;pd_col=pd_tft.color565(r*17,g*17,b*17);}
  inline void frect(int x,int y,int w,int h){pd_tft.fillRect(x*PD_SCALE,y*PD_SCALE+((pd_tft.height()-120*PD_SCALE)/2),w*PD_SCALE,h*PD_SCALE,pd_col);}
  inline bool button(uint32_t b){return pd_held&b;}
  inline bool pressed(uint32_t b){return (pd_held&b)&&!(pd_prev&b);}
  inline uint32_t time(){return millis();}
  inline void backlight(int){}
  struct voice_t{int f;};
  inline voice_t voice(uint32_t,uint32_t,uint32_t,uint32_t,int32_t,uint32_t,uint32_t,uint32_t){return {0};}
  inline void play(voice_t,uint32_t,uint32_t,uint32_t){}
}
