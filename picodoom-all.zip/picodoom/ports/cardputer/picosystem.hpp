// PicoSystem-API shim for the M5Stack Cardputer / Cardputer ADV (ESP32-S3, 240x135 LCD, keyboard)
#pragma once
#include <M5Cardputer.h>
#include <stdint.h>
extern M5Canvas pd_canvas; extern uint32_t pd_held, pd_prev; extern uint16_t pd_col;
namespace picosystem {
  static const uint32_t UP=1,DOWN=2,LEFT=4,RIGHT=8,A=16,B=32,X=64,Y=128;
  inline void pen(int r,int g,int b,int a=15){(void)a;pd_col=pd_canvas.color565(r*17,g*17,b*17);}
  // game renders 120x120; scale to 135x135 and centre on the 240x135 screen
  inline void frect(int x,int y,int w,int h){int x0=52+(x*135)/120,x1=52+((x+w)*135)/120,y0=(y*135)/120,y1=((y+h)*135)/120;pd_canvas.fillRect(x0,y0,x1-x0,y1-y0,pd_col);}
  inline bool button(uint32_t b){return pd_held&b;}
  inline bool pressed(uint32_t b){return (pd_held&b)&&!(pd_prev&b);}
  inline uint32_t time(){return millis();}
  inline void backlight(int v){M5Cardputer.Display.setBrightness(v*255/100);}
  struct voice_t{int f;};
  inline voice_t voice(uint32_t,uint32_t,uint32_t,uint32_t,int32_t,uint32_t,uint32_t,uint32_t){return {0};}
  inline void play(voice_t,uint32_t f,uint32_t d,uint32_t){M5Cardputer.Speaker.tone(f,d);}
}
